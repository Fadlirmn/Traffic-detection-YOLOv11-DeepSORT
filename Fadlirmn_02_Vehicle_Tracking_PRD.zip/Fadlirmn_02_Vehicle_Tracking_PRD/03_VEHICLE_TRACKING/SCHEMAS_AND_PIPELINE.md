# Vehicle Tracking — replay contract, schema, processing and tests

## 1. Export bundle
```
run-2026-demo/
  manifest.json
  events.jsonl
  tracks.jsonl
  detections.jsonl       # optional; large, may downsample for public overlay
  video.webm
  poster.webp
  aggregates.json
```
For public demo, bundle may be transformed into a seek-efficient **time-bucket JSON**; retain reference raw JSONL in repo or archive. Do not download a giant full detection JSON on first paint.

## 2. Manifest v1 example
```json
{
  "schemaVersion": "1.0.0",
  "runId": "sample-run-001",
  "mode": "recorded-inference",
  "createdAt": "2026-11-20T00:00:00Z",
  "source": {"name": "licensed-sample-clip", "rights": "document in media/rights-manifest.md", "sha256": "TO_BE_COMPUTED"},
  "video": {"asset": "video.webm", "width": 1280, "height": 720, "fpsNominal": 25, "durationMs": 60000},
  "model": {"name": "YOLO11", "weightsSha256": "TO_BE_COMPUTED", "inputSize": 640, "confidenceThreshold": 0.35},
  "tracker": {"name": "DeepSORT", "configVersion": "1"},
  "geometry": {"referenceWidth": 1280, "referenceHeight": 720, "countLines": [{"id": "line-1", "from": [400, 300], "to": [900, 300]}]},
  "provenance": {"engineGitCommit": "TO_BE_COMPUTED", "label": "Sample prerecorded output"},
  "files": {"events": "events.jsonl", "tracks": "tracks.jsonl", "aggregates": "aggregates.json"}
}
```
`TO_BE_COMPUTED` is **not** a real integrity hash and must be replaced for release. Sample illustrative values are not benchmark claims.

## 3. Event contracts
Tracking observation (JSON line):
```json
{"type":"track_observation","runId":"sample-run-001","frameIndex":128,"ptsMs":5120,"trackId":"42","objectClass":"car","confidence":0.91,"box":{"x":520,"y":310,"width":160,"height":90},"state":"confirmed"}
```
Crossing event:
```json
{"type":"line_crossing","eventId":"sample-run-001:42:line-1:in:1","runId":"sample-run-001","ptsMs":6820,"trackId":"42","objectClass":"car","lineId":"line-1","direction":"in","confidence":0.91}
```
Rules: timestamps >=0, finite numeric values; `frameIndex` >=0, `trackId` scoped per run; frame coordinate system same as manifest, box constrained to frame; event unique; `out`/`in` direction only if line orientation is defined.

## 4. Data access API (demo)
| Method | Path | Result |
|---|---|---|
| GET | `/api/demo/runs` | list fixtures |
| GET | `/api/demo/runs/{runId}/manifest` | manifest, hashes and URL paths |
| GET | `/api/demo/runs/{runId}/events?fromMs=&toMs=&class=` | bounded events |
| GET | `/api/demo/runs/{runId}/aggregates?bucketSec=30` | precomputed totals |
| GET | `/api/demo/runs/{runId}/export.csv` | labeled sample output |

Only allowlisted `runId`, no arbitrary file paths or SSRF. Validate query bounds (`fromMs <= toMs`, max window). Prefer static manifest/index and browser fetch if simple.

## 5. Processing correctness
- Detector output classes map through versioned dictionary to stable class taxonomy.
- Tracker update uses each frame's detections once, not repeated on display.
- Crossing classifier: centroid/bottom-center configurable, `signedDistance` and crossing direction; minimum distance and frame persistence suppress jitter.
- `eventId` can be derived deterministically; idempotent event sink handles replay duplicates.
- Invalid/overlapping frames produce diagnostic counters and are excluded deliberately.
- Export includes engine commit, library versions, device info, config and source rights manifest.

## 6. Required tests
| Unit | Positive / negative cases |
|---|---|
| Box mapper | resized input restored to original, clipped coordinates, empty list |
| Line crossing | one crossing, backwards, jitter, stationary, track disappears/reappears |
| Event ID | deterministic, unique across direction/sequence/run |
| Tracker adapter | no detection, occlusion, low confidence, out-of-order frame |
| Export | stable schema, invalid float rejection, datetime correctness |
| Demo time index | play/seek/pause, 0ms, last frame, clip end |
| Aggregation | count table exactly equals unique events in selected window |
| Rendering | accessible controls and safe missing video fallback |

## 7. Reproducible commands (target CLI interface)
```
python -m tracker infer --input ./samples/licensed.mp4 --config ./configs/sample.yaml --output ./out/run-a
python -m tracker export-replay --run ./out/run-a --dest ./apps/showcase/static/replays/run-a
python -m tracker benchmark --input ./samples/licensed.mp4 --repeat 3 --output ./out/benchmark.json
python -m pytest
```
Commands describe the **contract to implement**; they are not asserted to exist yet.
