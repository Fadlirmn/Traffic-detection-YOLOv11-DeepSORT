# PRD 02 — Vehicle Tracking: Real-time CV Engine + Replay Showcase

**Version:** 1.0 · **Priority:** P0 (featured) · **Mode:** Actual local/edge inference engine, Vercel video+metadata replay

## 1. Problem / positioning
A technically rigorous vehicle detection, tracking and counting system based on YOLO11 (often called YOLOv11) and DeepSORT, with reproducible inference, evaluation, event outputs and an intuitive browser viewer. It demonstrates Python, computer vision, edge computing and metrics instrumentation. **Public showcase is not live inference**; it replays genuine precomputed engine output with transparent timestamps and source provenance.

## 2. Stakeholders and target use
- Engineering reviewer checks tracking pipeline, model version, reproducibility and quantitative metrics.
- General visitor watches detections, IDs, count trends and system limitations without specialized hardware.
- Operator (real-mode local) loads a file/camera, configures ROI/line, starts/stops processing, exports events.

## 3. Goals (targets)
| ID | Goal | Evidence |
|---|---|---|
| G1 | Fully reproducible inference CLI on a documented sample video | command + deterministic export schema |
| G2 | Browser timeline synchronized to event JSON within 1 display frame at specified FPS tolerance | Playwright/frame tests |
| G3 | Tracking and line-crossing counting do not double count stable IDs | unit and golden tests |
| G4 | Report throughput and accuracy with hardware/dataset details, not marketing estimates | benchmark report |
| G5 | Public demo runs on Vercel without GPU, VPS or Python server | fixture/replay-only smoke test |
| G6 | No publication of unlicensed or identifiable media without consent | media checklist |

## 4. Functional boundaries
| Feature | Real implementation | Public showcase | Priority |
|---|---|---|---|
| Video file ingest | OpenCV decoder, file validation | versioned sample clip | P0 |
| Object detection | YOLO11 model in Python runtime | detections exported as sidecar JSON | P0 |
| Multi-object tracking | DeepSORT associating boxes IDs | rendered/replayed ID overlays | P0 |
| Crossing line counting | stable track IDs, direction rules | playback counter overlay | P0 |
| ROI masking | zone clipping logic | inspect overlay + optional preset selection | P0 |
| Timeline chart | derived events + snapshot metrics | synchronized charts and tables | P0 |
| CSV/JSON export | actual engine events | download sample export | P0 |
| Batch benchmark | scripts over labeled dataset | benchmark report if measured | P1 |
| Source camera / Raspberry Pi | device adapter, optional documented example | not connected on public demo | P1 |
| Network live stream, multi-camera | optional future | not promised | P2 |
| Alerts | optional event output interface | simulated event cards | P2 |

## 5. What will be demonstrated truthfully?
- Replay video clip **really processed by local Python engine** and exported event file.
- Overlay is drawn from actual event JSON or baked export (if baked, disclose); event time synchronized with media time.
- `Recorded inference`, `Sample dataset`, recording date and inference model/weights version displayed.
- If only synthetic example used during initial build, banner must say **Synthetic demo events**, not claim real inference.
- No `LIVE` indicators, live camera icons, or uptime/inference FPS claims without actual measured evidence.

## 6. Technology choices
| Layer | Tech | Notes |
|---|---|---|
| Engine | Python 3.x supported by libraries | modular pipeline, typed models |
| Detector | Ultralytics YOLO11 | validate commercial/open-source license and model weights |
| Tracker | DeepSORT maintained compatible implementation | check license/dependency API, freeze model seed |
| Image/video | OpenCV, NumPy | pre/postprocessing and video IO |
| Schemas | Pydantic v2 + JSON Schema | versioned exchange format |
| Metadata storage | SQLite for local single-file usage; optional PostgreSQL adapter | no public DB needed |
| CLI | Typer or argparse | reproducible headless execution |
| Demo UI | SvelteKit 5/TS/Tailwind + Canvas overlay | media time drives event selector |
| Hosting | Vercel + static JSON and compressed media/CDN | no GPU compute |
| Analysis | Pandas optional offline, plotting/JSON exporter | never required at request time |
| Test | pytest, golden fixtures, format/lint, Playwright | deterministic visual/event tests |

## 7. Pipeline architecture
```
source (file/camera) -> decode -> frame normalization -> detector
 -> confidence/NMS -> tracker -> track state and aging
 -> ROI/line-crossing event processor -> counts & statistics
 -> writer (JSONL/CSV, timing, metrics) -> visualization export

Public showcase:
pre-recorded MP4/WebM + event JSON + metadata manifest
 -> Vercel static/CDN -> browser media element
 -> frame-time-indexed overlay -> counts/timeline/table
```

### Source engine conventions
- Pipeline stages are separate interfaces; tracking is stateful only within a local processing session.
- Frames carry source frame index, PTS/video timestamp, resolution and orientation.
- Preprocess preserves mapping from model input pixels to original frame boxes.
- Count cross-line transitions with hysteresis/previous-side state; avoid oscillation/double count.
- Out-of-order, dropped, and uncertain frames handled explicitly; never invent IDs on display.
- Reproducibility requires pinned weights fingerprint, tracker configuration, seed (where relevant), input hash and hardware notes.

## 8. User stories
**US-01 Public replay (P0):** guest opens demo → first example loads → press play → bounding boxes and track IDs follow vehicle positions. Acceptance: current position queried from `<video>` `currentTime`, event buckets indexed using manifest FPS/time; controls support pause, seek, speed 0.5/1/1.5, keyboard and reduced motion.

**US-02 Count explanation (P0):** guest clicks direction `inbound`/`outbound` → table lists crossing events with timestamp, track ID, class and side transition. Acceptance: totals derived from unique event IDs and match displayed chart for the loaded recording.

**US-03 Analyze performance (P1):** guest views measured throughput and evaluation table. Acceptance: report states test machine (Raspberry Pi 5 if actually used), model weights, input size, FPS methodology, warmup and dataset samples; unmeasured values labeled N/A, not guessed.

**US-04 Local inference (P0):** developer runs `python -m tracker infer --input samples/vehicles.mp4 --config configs/demo.yaml --output out/run` → output manifest and events → replay app loads compatible bundle. Acceptance: exit nonzero on invalid inputs; processing errors recorded; JSON Schema validates output; published media rights checked.

**US-05 ROI preset (P0):** guest chooses preset line 1 or zone A → replay filters view to precomputed scenario; does **not** imply running new inference. Acceptance: counts agree with matching precomputed events; if no matching preset data, toggle is disabled.

## 9. Frontend IA
- `/` intro, recording status (pre-recorded), source code & explanation.
- `/demo` video player, overlays, time scrubber, playback speed, track class filter, direction counts.
- `/demo/events` searchable event table with CSV export and filters.
- `/demo/analytics` volume over time, class distribution, track lifespan, performance evidence.
- `/methodology` dataset/sample details, model/tracker configuration, evaluation metrics, limitations.
- `/architecture` pipeline graphic and implementation details.

## 10. Domain business rules
- Entity class taxonomy (car, motorcycle, bus, truck; optionally bicycle) maps model class IDs to stable names.
- Each detection: frame index, box in original dimensions, label, score 0..1.
- Each track: stable `track_id` within run; activation/retention TTL config; state `tentative|confirmed|lost|deleted` or tracker mapping.
- Each crossing: unique event `runId:trackId:lineId:direction:crossingSequence`, timestamp and source.
- One physical vehicle might be assigned two IDs after occlusion; disclose limitation and evaluate ID switches.
- Aggregate count uses unique finalized crossing events, no incremental count based on bounding box count.
- Bounding boxes clipped to valid coordinates, never negative/NaN; time base monotonic.

## 11. Evaluation & benchmark plan
Report only observed results using explicit standardized protocol:
- Data: source/right-to-use, sample count, clip duration, annotations if accuracy metrics computed.
- Devices: CPU/GPU model, RAM, OS, package versions; note Raspberry Pi 5 exact configuration only if tested.
- Performance: latency p50/p95 in ms per frame, throughput FPS, decode/inference/tracker breakdown; 3 runs, warmup defined.
- Detection: precision, recall, mAP only if labeled ground truth exists and correct evaluation code used.
- Tracking: IDF1/MOTA/HOTA/ID switches only if valid ground truth and methodology; otherwise report `not measured`.
- Counting: MAE/MAPE (avoid MAPE at zero denominator), per-direction count error vs ground truth.
- Export benchmark artifacts as checked-in sanitized Markdown/JSON with date.

## 12. Media & data safety
- Only approved/synthetic/public-rights source videos; check faces, license plates, GPS and metadata; blur/anonymize if necessary.
- Avoid exposing surveillance equipment credentials, camera URLs, private scenes or location histories.
- No public arbitrary video upload for first release, which reduces malicious media handling/cost.
- Clip optimized for bandwidth, poster thumbnail, captions or description for accessibility, 720p max initially.
- Stable manifest hash validates JSON and video pairing; graceful fallback if media unavailable.

## 13. NFR & quality
- Demo: first meaningful image within 3 sec target on test connection; mobile fallback for overlay-heavy viewer.
- Browser video/time sync: frame bucket tolerances and drift correction when seeking; overlay update via `requestVideoFrameCallback` when supported, fallback `timeupdate`/rAF carefully.
- A11y: playback keyboard, alternative table for boxes/events, captions/transcript of key visual events.
- Engine: logs per stage, resilient invalid frames, bounded video memory usage; configurable CPU fallback.
- Security: pinned dependencies, model weight verification by hash; sandbox untrusted media locally.
- Full screen and touch controls tested; render overlay with device-pixel-ratio awareness.

## 14. Acceptance matrix
| ID | Test | Expected |
|---|---|---|
| AC-01 | Open demo without backend/GPU | video and events work |
| AC-02 | Seek to 00:15 and pause | overlay matches frame index |
| AC-03 | Filter `motorcycle` | only relevant events/boxes show |
| AC-04 | Replay 3 times | counts stable, no duplicate event entries |
| AC-05 | Invalid event schema | safe error, no page crash |
| AC-06 | Offline/browser reload fixture | documented fallback or offline hint |
| AC-07 | Local inference invalid file | safe error + exit code |
| AC-08 | Detector output outside image bounds | values normalized/clipped |
| AC-09 | Keyboard-only player | usable with focus indicator |
| AC-10 | Public page claims | all replay/benchmark labels accurate |

## 15. Repository design
```
engine/tracker/{detectors,trackers,events,geometry,io,cli}
engine/configs/
engine/tests/{unit,golden,integration}
apps/showcase/src/routes/{demo,analytics,methodology,architecture}
fixtures/replays/{sample-a/manifest.json,events.json,poster.webp}
media/{README,rights-manifest.md}  # large media on CDN or Git LFS where appropriate
scripts/{export-replay,benchmark,validate-manifest}
docs/{adr,methodology,benchmark-results}
```
Do not commit proprietary model weights or raw private footage to public repo. Provide verified download instructions and integrity hashes.

## 16. Rollout tasks
1. Freeze taxonomy/event schema. 2. Implement video + model adapter, CPU sample inference. 3. DeepSORT and crossing rules with golden tests. 4. Capture/export sanctioned sample. 5. Build Vercel replay UI and chart. 6. Test timing. 7. Publish benchmark evidence or explicitly `not measured`. 8. Accessibility/media audit. 9. CI and README runbook. 10. Publish.

## 17. Risks
- Model weights and license restrictions: review and document; do not assume AGPL/commercial suitability.
- ID switches and occlusion: visualize limitations rather than conceal.
- Raspberry Pi performance: avoid promising real-time without hardware benchmark.
- Model inference in browser/serverless: not part of P0; no complex GPU serverless commitment.
